package entities;

public class WorkerRow implements AbstractRow {
    public final static String[] TableColumns = {"id", "firstName", "lastName", "experience", "store_id"};
    public final static boolean[] isThisInt = {true, false, false, true, true};

    public int id;
    public String firstName;
    public String lastName;
    public int experience;
    public int store_id;

    @Override
    public int getId() {
        return id;
    }

    public WorkerRow(int id, String firstName, String lastName, int experience, int store_id){
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.experience = experience;
        this.store_id = store_id;
    }
}
