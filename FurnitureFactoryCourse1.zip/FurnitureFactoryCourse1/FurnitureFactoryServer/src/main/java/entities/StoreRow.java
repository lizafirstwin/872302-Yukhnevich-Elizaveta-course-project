package entities;

public class StoreRow implements AbstractRow {
    public final static String[] TableColumns = {"id", "name", "adress"};
    public final static boolean[] isThisInt = {true, false, false};

    public int id;
    public String name;
    public String adress;

    @Override
    public int getId() {
        return id;
    }

    public StoreRow(int id, String name, String adress){
        this.id = id;
        this.name = name;
        this.adress = adress;
    }
}
