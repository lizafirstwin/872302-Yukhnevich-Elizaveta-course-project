package entities;

public class QualityRow implements AbstractRow {
    public final static String[] TableColumns = {"id", "name", "category", "point", "point_buyers", "importance", "product_id"};
    public final static boolean[] isThisInt = {true, false, false, true, true, true, true};

    public int id;
    public String name;
    public String category;
    public int point;
    public int point_buyers;
    public int importance;
    public int product_id;

    @Override
    public int getId() {
        return id;
    }

    public QualityRow(int id, String name, String category, int point, int point_buyers, int product_id, int importance){
        this.id = id;
        this.name = name;
        this.category = category;
        this.point = point;
        this.point_buyers = point_buyers;
        this.product_id = product_id;
        this.importance = importance;
    }

}
