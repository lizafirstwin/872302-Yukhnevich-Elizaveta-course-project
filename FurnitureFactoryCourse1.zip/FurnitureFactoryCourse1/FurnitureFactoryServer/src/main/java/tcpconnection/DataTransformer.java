package tcpconnection;

import mysqlconnection.ExecuteSQL;
import entities.*;
import serialization.Gsonizator;

import java.util.ArrayList;

public class DataTransformer {
    private ExecuteSQL connectorToMySQL = new ExecuteSQL();

    public String mainworkersearch(String data){
        AccountRow account = (AccountRow) Gsonizator.degsonisations(data, AccountRow.class);
        ArrayList<AccountRow> accounts = connectorToMySQL.select_accounts("",generateWhere(account));
        return accounts.size() > 0 ? Gsonizator.gsonisation(accounts.get(0)) : "";

    }

    private String generateWhere(AccountRow account){
        return "`login` = '" + account.login + "' AND `password` = '" + account.password + "'";
    }


    public String getAllTableData(String stringOrderBySortAndWhere, Class<? extends AbstractRow> thisTableClass){
        String componentsQuery[] = new String[]{"", ""};
        if(!(stringOrderBySortAndWhere.equals("")))
            componentsQuery = stringOrderBySortAndWhere.split("~~~~~");
        return selectMainUser(componentsQuery[0], componentsQuery[1], thisTableClass);
    }

    private String selectMainUser(String table, String data, Class<? extends AbstractRow> thisTableClass){
        switch (thisTableClass.getName()) {
            default:
            case "entities.AccountRow":     return Gsonizator.gsonisations(connectorToMySQL.select_accounts(table, data));
            case "entities.QualityRow":      return Gsonizator.gsonisations(connectorToMySQL.select_qualitys(table, data));
            case "entities.ProductRow":     return Gsonizator.gsonisations(connectorToMySQL.select_products(table, data));
            case "entities.StoreRow":     return Gsonizator.gsonisations(connectorToMySQL.select_stores(table, data));
            case "entities.WorkerRow":         return Gsonizator.gsonisations(connectorToMySQL.select_workers(table, data));
           }
    }


    public String delete(String data){
        String componentsQuery[] = data.split("~~~~~");
        if(connectorToMySQL.delete(componentsQuery[0], Integer.valueOf(componentsQuery[1])).equals("")) return "ok";
        else  return "";
    }

    public String insert(String data, String table, Class<? extends AbstractRow> thintegerFormatCheckerface){
        if(connectorToMySQL.insert(Gsonizator.degsonisations(data, thintegerFormatCheckerface), table).equals("")) return "ok";
        else return "";

    }

    public String update(String data, String table, Class<? extends AbstractRow> thintegerFormatCheckerface){
        String componentsQuery[] = data.split("~~~~~");
        if(connectorToMySQL.update(Gsonizator.degsonisations(componentsQuery[0], thintegerFormatCheckerface)
                , table, Integer.valueOf(componentsQuery[1])).equals(""))return "ok";
        else return "";
    }

}
