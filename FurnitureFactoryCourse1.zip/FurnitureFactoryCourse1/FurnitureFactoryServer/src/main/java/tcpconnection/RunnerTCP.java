package tcpconnection;

import entities.*;

import java.io.*;
import java.net.Socket;

public class RunnerTCP extends Thread{
    private ClientConnection thisMainSocket;
    private Socket thisSocketForClient;
    private boolean isWeDon = false;
    public boolean isWeHaveAProblem = false;


    public RunnerTCP(Socket thisSocketForClient, ClientConnection thisMainSocket) {
        this.thisSocketForClient = thisSocketForClient;
        this.thisMainSocket = thisMainSocket;
        start();
    }

    public void run(){
        try {
            ObjectOutputStream stream_out = new ObjectOutputStream(thisSocketForClient.getOutputStream());
            ObjectInputStream stream_in = new ObjectInputStream(thisSocketForClient.getInputStream());
            while (!isWeDon) {
                String command = stream_in.readObject().toString();
                String data = stream_in.readObject().toString();
                oneJob( command,  data, stream_out);
            }
            exiting(stream_out, stream_in);
        } catch (Exception e){
            isWeHaveAProblem = true;
            isWeDon = true;
        }
    }

    private void oneJob(String command, String data, ObjectOutputStream stream_out) throws Exception{

        String response = runCommand(command, data);
        isWeHaveAProblem = false;
        if(!response.equals("exit")) stream_out.writeObject(response);
    }

    private String runCommand(String command, String data){
        DataTransformer dataTransformer = new DataTransformer();

        String response;
        switch (command){
            case "authorization":
                response = dataTransformer.mainworkersearch(data);break;
            case "select_accounts":
                response = dataTransformer.getAllTableData(data, AccountRow.class);break;
            case "select_qualitys":
                response = dataTransformer.getAllTableData(data, QualityRow.class);break;
            case "select_products":
                response = dataTransformer.getAllTableData(data, ProductRow.class);break;
            case "select_stores":
                response = dataTransformer.getAllTableData(data, StoreRow.class);break;
            case "select_workers":
                response = dataTransformer.getAllTableData(data, WorkerRow.class);break;
            case "delete":
                response = dataTransformer.delete(data);break;
            case "insert_accounts":
                response = dataTransformer.insert(data, "accounts", AccountRow.class);break;
            case "insert_qualitys":
                response = dataTransformer.insert(data, "qualitys", QualityRow.class);break;
            case "insert_products":
                response = dataTransformer.insert(data, "products", ProductRow.class);break;
            case "insert_stores":
                response = dataTransformer.insert(data, "stores", StoreRow.class);break;
            case "insert_workers":
                response = dataTransformer.insert(data, "workers", WorkerRow.class);break;
            case "update_accounts":
                response = dataTransformer.update(data, "accounts", AccountRow.class);break;
            case "update_qualitys":
                response = dataTransformer.update(data, "qualitys", QualityRow.class);break;
            case "update_products":
                response = dataTransformer.update(data, "products", ProductRow.class);break;
            case "update_stores":
                response = dataTransformer.update(data, "stores", StoreRow.class);break;
            case "update_workers":
                response = dataTransformer.update(data, "workers", WorkerRow.class); break;
            default: case "exit":
                isWeDon = true; response = "exit"; break;
        }
        return response;
    }

    public void exiting(ObjectOutputStream stream_out, ObjectInputStream stream_in){
        try {
            stream_in.close();
            stream_out.close();
            thisSocketForClient.close();
            thisMainSocket.acceptClientsSocket.remove(this);
            isWeHaveAProblem = false;
        } catch (IOException e) {
            isWeHaveAProblem = true;
        } finally {
            thisMainSocket.dialog.ThisFields.get(0).setText("" + (--thisMainSocket.quantyClientConnection));
        }
    }



}
