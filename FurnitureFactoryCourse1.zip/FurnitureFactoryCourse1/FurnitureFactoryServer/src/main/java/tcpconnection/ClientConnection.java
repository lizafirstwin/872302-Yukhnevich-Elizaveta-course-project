package tcpconnection;

import usergui.ServerDialog;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;


public class ClientConnection extends Thread {
    public ArrayList<RunnerTCP> acceptClientsSocket = new ArrayList<>();
    private ServerSocket serverSocket = null;
    public int quantyClientConnection = 0;
    private int thisRunningPort;
    public boolean isWeHaveAProblem = false;
    public ServerDialog dialog;

    public ClientConnection(int thisRunningPort , ServerDialog dialog) {
        this.thisRunningPort = thisRunningPort;
        this.dialog = dialog;
        start();
    }

    public void run(){
        try {
            serverSocket = new ServerSocket(thisRunningPort);
            do {
                runOne();
            } while(true);
        } catch (Exception e) {
            isWeHaveAProblem = true;
        }
    }

    private void runOne() throws IOException {
        acceptClientsSocket.add(new RunnerTCP(serverSocket.accept(), this));
        dialog.ThisFields.get(0).setText("" + (++quantyClientConnection));
    }

    public void CloseServerListing() {
        try {
            for (int i = 0; i < acceptClientsSocket.size(); i++) {
                acceptClientsSocket.get(i).interrupt();
            }
        } catch (Exception e) {
            isWeHaveAProblem = true;
        }
        interrupt();
    }

}
