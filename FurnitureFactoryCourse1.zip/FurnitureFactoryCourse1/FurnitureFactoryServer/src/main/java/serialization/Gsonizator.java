package serialization;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import entities.AbstractRow;

import java.util.ArrayList;

public class Gsonizator {
    public static String gsonisation(AbstractRow abstractRow) {
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        return gson.toJson(abstractRow);
    }

    public static AbstractRow degsonisations(String stringMessage, Class<? extends AbstractRow> thintegerFormatCheckerface) {
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        return gson.fromJson(stringMessage, thintegerFormatCheckerface);
    }

    public static String gsonisations(ArrayList<? extends AbstractRow> abstractRows) {
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        return gson.toJson(abstractRows);
    }
}
