package usergui;

import tcpconnection.ClientConnection;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class WindowPreRunning {
    private ServerDialog frameDialogServer;
    ServerDialog serverDialogCurrent;
    private int portForStarted;
    private ClientConnection thisMainSocket;


    public WindowPreRunning(int portForStarted, ServerDialog frameDialogServer){
        this.frameDialogServer = frameDialogServer;
        this.portForStarted = portForStarted;
        addDefInfoInDialog();
        setEventForWindow();
        serverDialogCurrent.setVisible(true);
    }

    private void addDefInfoInDialog(){
        serverDialogCurrent = new ServerDialog("Сервер!", 250, 300);
        serverDialogCurrent.addLabel(200, 25,15, 20, "Слушаем подключения...");
        serverDialogCurrent.addLabel(200, 25,15, 60, "Рабочий порт: " + String.valueOf(portForStarted));
        serverDialogCurrent.addLabel(200, 25,15, 110, "Кол-во клиентов:");
        serverDialogCurrent.addTextField(200, 25,15, 160, "0");
        serverDialogCurrent.ThisFields.get(0).setEnabled(false);
        serverDialogCurrent.addButton(200, 25, 15, 210, "Закрыть");
    }

    private void setEventForWindow(){
        ActionListener actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                thisMainSocket.CloseServerListing();
                if(thisMainSocket.isWeHaveAProblem) JOptionPane.showMessageDialog(serverDialogCurrent,"Некорректно вышли из системы!");
                closeAll();
            }
        };
        serverDialogCurrent.ThisButtons.get(0).addActionListener(actionListener);
        addWindowListener();
    }

    private void closeAll(){
        frameDialogServer.close();
        serverDialogCurrent.close();
    }

    private void addWindowListener(){
        WindowListener windowListener = new WindowListener() {
            public void windowActivated(WindowEvent event) {}
            public void windowClosed(WindowEvent event) {}
            public void windowDeactivated(WindowEvent event) {}
            public void windowDeiconified(WindowEvent event) {}
            public void windowIconified(WindowEvent event) {}
            public void windowOpened(WindowEvent event) {
                thisMainSocket = new ClientConnection(portForStarted, serverDialogCurrent);
                if(thisMainSocket.isWeHaveAProblem){
                    JOptionPane.showMessageDialog(serverDialogCurrent, "Ошибка запуска сервера");
                    serverDialogCurrent.dispose();
                }
            }
            public void windowClosing(WindowEvent event) {
                thisMainSocket.CloseServerListing();
                if(thisMainSocket.isWeHaveAProblem)JOptionPane.showMessageDialog(serverDialogCurrent, "Ошибка закрытия сервера");

            }
        };
        serverDialogCurrent.addWindowListener(windowListener);
    }


}
