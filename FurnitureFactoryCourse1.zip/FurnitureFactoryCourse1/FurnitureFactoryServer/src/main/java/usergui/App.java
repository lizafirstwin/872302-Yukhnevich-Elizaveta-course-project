package usergui;

public class App {
    public static void main(String[] args) {
        new WindowRunning();
    }

    public static boolean integerFormatCheck(String stringMessage){
        try {
            Integer.valueOf(stringMessage);
            return true;
        } catch (Exception e){
            return false;
        }
    }
}
