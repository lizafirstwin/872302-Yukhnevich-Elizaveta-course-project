package usergui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

public class ServerDialog extends JFrame {
    public void close(){
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }

    private JPanel myPanelWithData;
    public ArrayList<JButton> ThisButtons = new ArrayList<>();
    public ArrayList<JTextField> ThisFields = new ArrayList<>();
    public ArrayList<JLabel> ThisLabels = new ArrayList<>();

    public ServerDialog(String headText, int widthDialog, int heightDialog){
        super(headText);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(widthDialog, heightDialog);
        setDefault();
        setContentPane(myPanelWithData);
    }

    private void setDefault(){
        myPanelWithData = new JPanel();
        myPanelWithData.setLayout(null);
        myPanelWithData.setBackground(Color.WHITE);
        myPanelWithData.setForeground(Color.BLACK);
        setLocationRelativeTo(null);
    }


    public void addButton(int widthDialog, int heightDialog, int xPointDialog, int yPointDialog, String headText){
        JButton myButton = new JButton(headText);
        myButton.setSize(widthDialog, heightDialog);
        myButton.setLocation(xPointDialog, yPointDialog);
        myButton.setBackground(Color.WHITE);
        myButton.setForeground(Color.BLACK);
        myPanelWithData.add(myButton);
        ThisButtons.add(myButton);
    }


    public void addTextField(int widthDialog, int heightDialog, int xPointDialog, int yPointDialog, String headText){
        JTextField myTextField = new JTextField(headText);
        myTextField.setSize(widthDialog, heightDialog);
        myTextField.setLocation(xPointDialog,yPointDialog);
        myTextField.setForeground(Color.BLACK);
        myPanelWithData.add(myTextField);
        ThisFields.add(myTextField);
    }

    public void addLabel(int widthDialog, int heightDialog, int xPointDialog, int yPointDialog, String headText){
        JLabel myLabel = new JLabel(headText);
        myLabel.setSize(widthDialog, heightDialog);
        myLabel.setLocation(xPointDialog,yPointDialog);
        myLabel.setForeground(Color.BLACK);
        myPanelWithData.add(myLabel);
        ThisLabels.add(myLabel);
    }
}




