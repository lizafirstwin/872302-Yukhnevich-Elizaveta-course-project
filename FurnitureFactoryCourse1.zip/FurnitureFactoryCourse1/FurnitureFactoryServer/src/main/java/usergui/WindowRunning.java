package usergui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class WindowRunning {
    private ServerDialog runningServerWindow;
    private String messageWithErrorCode = "";

    public WindowRunning(){
        addDefault();

        runningServerWindow.ThisButtons.get(0).addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                messageWithErrorCode = "";
                if(isGetDataFromFile()) {
                    new WindowPreRunning(Integer.valueOf(runningServerWindow.ThisFields.get(0).getText()), runningServerWindow);
                    runningServerWindow.dispose();
                } else {
                    JOptionPane.showMessageDialog(runningServerWindow, "ERROR:\r\n" + messageWithErrorCode);
                }
            }
        });
        runningServerWindow.setVisible(true);
    }

    private void addDefault(){
        runningServerWindow = new ServerDialog("Запуск Сервера", 250, 230);
        runningServerWindow.addLabel(200, 40, 15, 20, "Запуск сервера!");
        runningServerWindow.addLabel(200, 40, 15, 50, "Порт сервера:");
        runningServerWindow.addTextField(200, 40, 15, 80, "2020");
        runningServerWindow.addButton(200, 40, 15, 130, "Запуск");

    }





    private boolean isGetDataFromFile() {
        if(!App.integerFormatCheck(runningServerWindow.ThisFields.get(0).getText())){
            messageWithErrorCode += "Порт не является Целым Числом";
        } else {
            if(Integer.valueOf(runningServerWindow.ThisFields.get(0).getText()) <= 1255
                    || Integer.valueOf(runningServerWindow.ThisFields.get(0).getText()) > 65350){
                messageWithErrorCode += "Порт вне допустимых диапазонов";
            }
        }
        return messageWithErrorCode.equals("") ? true : false;
    }
}
