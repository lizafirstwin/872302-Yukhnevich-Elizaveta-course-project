package mysqlconnection;

import entities.*;

import java.util.ArrayList;

public class ExecuteSQL {
    private ConnectSQL mySQLConnector =  ConnectSQL.getInstance();
    public boolean isWeHaveAProblem = false;


    public ArrayList<AccountRow> select_accounts(String stringOrderBySort, String where){
        try {
            ArrayList<AbstractRow> abstractRows;
            ArrayList<AccountRow> accounts = new ArrayList<>();
            abstractRows = mySQLConnector.select("accounts", where, stringOrderBySort);

            return addOneAccount(abstractRows, accounts);
        } catch (Exception e){
            isWeHaveAProblem = true;
            return null;
        }
    }

    private ArrayList<AccountRow> addOneAccount(ArrayList<AbstractRow> abstractRows, ArrayList<AccountRow> models){
        for (int i = 0; i < abstractRows.size(); i++)
            models.add((AccountRow) abstractRows.get(i));
        return models;
    }

    private ArrayList<QualityRow> addOneQuality(ArrayList<AbstractRow> abstractRows, ArrayList<QualityRow> models){
        for (int i = 0; i < abstractRows.size(); i++)
            models.add((QualityRow) abstractRows.get(i));
        return models;
    }

    private ArrayList<ProductRow> addOneProduct(ArrayList<AbstractRow> abstractRows, ArrayList<ProductRow> models){
        for (int i = 0; i < abstractRows.size(); i++)
            models.add((ProductRow) abstractRows.get(i));
        return models;
    }


    private ArrayList<StoreRow> addOneStore(ArrayList<AbstractRow> abstractRows, ArrayList<StoreRow> models){
        for (int i = 0; i < abstractRows.size(); i++)
            models.add((StoreRow) abstractRows.get(i));
        return models;
    }


    private ArrayList<WorkerRow> addOneWorker(ArrayList<AbstractRow> abstractRows, ArrayList<WorkerRow> models){
        for (int i = 0; i < abstractRows.size(); i++)
            models.add((WorkerRow) abstractRows.get(i));
        return models;
    }

    public ArrayList<QualityRow> select_qualitys(String stringOrderBySort, String where){
        try {
            ArrayList<AbstractRow> abstractRows;
            ArrayList<QualityRow>  qualitys = new ArrayList<>();
            abstractRows = mySQLConnector.select("qualitys",   where, stringOrderBySort);
            return addOneQuality(abstractRows, qualitys);
        } catch (Exception e){
            isWeHaveAProblem = true;
            return null;
        }
    }



    public ArrayList<ProductRow> select_products(String stringOrderBySort, String where){
        try {
            ArrayList<AbstractRow> abstractRows;
            ArrayList<ProductRow>  products = new ArrayList<>();
            abstractRows = mySQLConnector.select("products",   where, stringOrderBySort);

            return addOneProduct(abstractRows, products);
        } catch (Exception e){
            isWeHaveAProblem = true;
            return null;
        }
    }

    public ArrayList<StoreRow> select_stores(String stringOrderBySort, String where){
        try {
            ArrayList<AbstractRow> abstractRows;
            ArrayList<StoreRow>  stores = new ArrayList<>();
            abstractRows = mySQLConnector.select("stores",  where, stringOrderBySort);

            return addOneStore(abstractRows, stores);
        } catch (Exception e){
            isWeHaveAProblem = true;
            return null;
        }
    }


    public ArrayList<WorkerRow> select_workers(String stringOrderBySort, String where){
        try {
            ArrayList<AbstractRow> abstractRows;
            ArrayList<WorkerRow>  workers = new ArrayList<>();
            abstractRows = mySQLConnector.select("workers", where, stringOrderBySort);

            return addOneWorker(abstractRows, workers);
        } catch (Exception e){
            isWeHaveAProblem = true;
            return null;
        }
    }


    public String delete(String table, int id) {
        try {
            if (mySQLConnector.delete(table,id)) {
                return "";
            } else {
                return "Data has not deleted";
            }
        } catch (Exception e){
            isWeHaveAProblem = true;
            return e.getMessage();
        }
    }

    public String insert(AbstractRow abstractRow, String table) {
        try {
            String queryToMySQLComponents[] = pre_queryToMySQLComponents(abstractRow);
			boolean isHaveError = mySQLConnector.insert(table, queryToMySQLComponents[0], queryToMySQLComponents[1]);
            if (isHaveError) {
                return "";
            } else {
                return "Data has not inserted";
            }
        } catch (Exception  e){
            isWeHaveAProblem = true;
            return e.getMessage();
        }
    }


    private String[] pre_queryToMySQLComponents(AbstractRow abstractRow){
        if(abstractRow instanceof AccountRow){
            return pre_accountsqueryToMySQL((AccountRow) abstractRow);
        }
        if(abstractRow instanceof QualityRow){
            return pre_qualitysqueryToMySQL((QualityRow) abstractRow);
        }
        if(abstractRow instanceof ProductRow){
            return pre_productsqueryToMySQL((ProductRow) abstractRow);
        }
        if(abstractRow instanceof StoreRow){
            return pre_storesqueryToMySQL((StoreRow) abstractRow);
        }
        if(abstractRow instanceof WorkerRow){
            return pre_workersqueryToMySQL((WorkerRow) abstractRow);
        }
        return null;
    }

    private String pre_Columns(String columns[]){
        String str = "";
        for (int i = 1; i < columns.length; i++) {
            str += columns[i];
            if(i != columns.length - 1) str +=",";
        }
        return str;
    }

    private String[] pre_accountsqueryToMySQL(AccountRow abstractMod){
        String str[] = new String[]{"", ""};
        str[0] = pre_Columns(AccountRow.TableColumns);
        str[1] = "'" + abstractMod.login + "','" + abstractMod.password + "'," + abstractMod.accountRole
                + "," + abstractMod.worker_id;
        return str;
    }

    private String[] pre_qualitysqueryToMySQL(QualityRow abstractMod){
        String str[] = new String[]{"", ""};
        str[0] = pre_Columns(QualityRow.TableColumns);
        str[1] = "'" + abstractMod.name + "','" + abstractMod.category + "'," + abstractMod.point + ","
                + abstractMod.point_buyers + "," + abstractMod.product_id + "," + abstractMod.importance;
        return str;
    }

    private String[] pre_productsqueryToMySQL(ProductRow abstractMod){
        String str[] = new String[]{"", ""};
        str[0] = pre_Columns(ProductRow.TableColumns);
        str[1] = "'" + abstractMod.name + "'," + abstractMod.price + "," + abstractMod.self_price + "," + abstractMod.store_id;
        return str;
    }

    private String[] pre_storesqueryToMySQL(StoreRow abstractMod){
        String str[] = new String[]{"", ""};
        str[0] = pre_Columns(StoreRow.TableColumns);
        str[1] = "'" + abstractMod.name + "'," + abstractMod.adress + "'";
        return str;
    }

    private String[] pre_workersqueryToMySQL(WorkerRow abstractMod){
        String str[] = new String[]{"", ""};
        str[0] = pre_Columns(WorkerRow.TableColumns);
        str[1] = "'" + abstractMod.firstName + "','" + abstractMod.lastName + "'," + abstractMod.experience + ","
                + abstractMod.store_id;
        return str;
    }


    public String update(AbstractRow abstractRow, String table, int id) {
        try {
            String values = pre_queryToMySQLUpdateColumns(abstractRow);
            if (mySQLConnector.update(table, id, values)) {
                return "";
            } else {
                return "Data has not updated";
            }
        } catch (Exception e){
            isWeHaveAProblem = true;
            return e.getMessage();
        }
    }

    private String pre_queryToMySQLUpdateColumns(AbstractRow abstractRow){
        if(abstractRow instanceof AccountRow){
            return pre_accountsUpdateColumns((AccountRow) abstractRow);
        }
        if(abstractRow instanceof QualityRow){
            return pre_qualitysUpdateColumns((QualityRow) abstractRow);
        }
        if(abstractRow instanceof ProductRow){
            return pre_productsUpdateColumns((ProductRow) abstractRow);
        }
        if(abstractRow instanceof StoreRow){
            return pre_storesUpdateColumns((StoreRow) abstractRow);
        }
        if(abstractRow instanceof WorkerRow){
            return pre_workersUpdateColumns((WorkerRow) abstractRow);
        }
        return "";
    }

    private String pre_accountsUpdateColumns(AccountRow abstractMod){
        return "login = '" + abstractMod.login + "', password = '" + abstractMod.password + "',accountRole = " +
                abstractMod.accountRole + ", worker_id = " + abstractMod.worker_id;
    }

    private String pre_qualitysUpdateColumns(QualityRow abstractMod){
        return "name = '" + abstractMod.name + "', category = '" + abstractMod.category + "', point = " + abstractMod.point
                + ", point_buyers = " + abstractMod.point_buyers+ ",product_id = " + abstractMod.product_id + ",importance = " + abstractMod.importance;
    }

    private String pre_productsUpdateColumns(ProductRow abstractMod){
        return "name = '" + abstractMod.name + "', price = " + abstractMod.price+ ", self_price = " + abstractMod.self_price
                + ",store_id = " + abstractMod.store_id;
    }

    private String pre_storesUpdateColumns(StoreRow abstractMod){
        return "name = '" + abstractMod.name + "',adress = '" + abstractMod.adress + "'";

    }

    private String pre_workersUpdateColumns(WorkerRow abstractMod){
        return "firstName = '" + abstractMod.firstName + "',lastName = '" + abstractMod.lastName +
                "',experience = " + abstractMod.experience + ",store_id = " + abstractMod.store_id;
    }

}
