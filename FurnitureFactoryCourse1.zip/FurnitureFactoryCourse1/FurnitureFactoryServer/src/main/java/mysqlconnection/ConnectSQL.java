package mysqlconnection;

import entities.*;

import java.sql.*;
import java.util.ArrayList;

public class ConnectSQL {
    private static ConnectSQL connectSQL = new ConnectSQL();
    private final static String root = "root";
    private final static String MySQL_URL = "jdbc:mysql://localhost:3306/furniture_factory_database?useLegacyDatetimeCode=false&serverTimezone=UTC&useSSL=false";
    public boolean isWeHaveAProblem = false;
    Connection thisConnectionObject = null;
    Statement thisStatementObject = null;

    public static ConnectSQL getInstance() {
        return connectSQL;
    }

    private ConnectSQL() {
        try {
             Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e){
            isWeHaveAProblem = true;
        }
    }


    public boolean insert (String table, String columns, String values){
        String queryToMySQL = "insert into " + table + "(" + columns + ") values (" + values + ")";
        return queryExecuteUpdate(queryToMySQL).equals("");
    }

    public boolean update (String table, int id, String values){
        String queryToMySQL = "update " + table + " set " + values + " where id = " + id;
        return queryExecuteUpdate(queryToMySQL).equals("");

    }

    public boolean delete (String table, int id){
        String queryToMySQL = "delete from " + table + " where id =" + id;
        return queryExecuteUpdate(queryToMySQL).equals("");
    }

    public ArrayList<AbstractRow> select(String table, String stringWhereBySearch, String stringOrderBySort) {
        try {
            thisConnectionObject = DriverManager.getConnection(MySQL_URL, root, root);
            thisStatementObject = thisConnectionObject.createStatement();
            //System.out.println("select * from `" + table + "` " + stringWhereBySearch + " " + stringOrderBySort);
            ResultSet myResult = thisStatementObject.executeQuery(createQuery(table,stringWhereBySearch,stringOrderBySort));

            ArrayList<AbstractRow> qualitys = new ArrayList<>();
            while (myResult.next()) qualitys.add(resToModel(myResult, table));
            return qualitys;
        } catch (Exception e){
            isWeHaveAProblem = true;
            return null;
        } finally {
            try{
                thisConnectionObject.close();
                thisStatementObject.close();
            } catch (Exception e){
                return null;
            }
        }
    }

    private String createQuery(String table, String stringWhereBySearch, String stringOrderBySort){
        if(!("".equals(stringOrderBySort.trim()))) stringOrderBySort = "order by " + stringOrderBySort;
        if(!("".equals(stringWhereBySearch.trim()))) stringWhereBySearch = "where " + stringWhereBySearch;
        return "select * from `" + table + "` " + stringWhereBySearch + " " + stringOrderBySort;
    }

    private String queryExecuteUpdate(String queryToMySQL){
        try{
            thisConnectionObject = DriverManager.getConnection(MySQL_URL, root, root);
            thisStatementObject = thisConnectionObject.createStatement();
            thisStatementObject.executeUpdate(queryToMySQL);
            return "";
        } catch (Exception e){
            return isWeHaveAProblem ? e.getMessage() : "";
        } finally {
            try{
                thisConnectionObject.close();
                thisStatementObject.close();
            } catch (Exception e){
                return e.getMessage();
            }
        }
    }

    private AbstractRow resToModel(ResultSet myResult, String table){
        try {
            switch (table) {
                case "accounts": return res_set_to_accounts(myResult);
                case "qualitys": return res_set_to_qualitys(myResult);
                case "products": return res_set_to_products(myResult);
                case "stores": return res_set_to_stores(myResult);
                default:case "workers": return res_set_to_workers(myResult);
            }
        } catch (Exception e){
            isWeHaveAProblem = true;
            return null;
        }
    }


    private QualityRow res_set_to_qualitys(ResultSet myResult) throws Exception  {
        QualityRow qualityRow = new QualityRow(
            myResult.getInt(1),
            myResult.getString(2),
            myResult.getString(3),
            myResult.getInt(4),
            myResult.getInt(5),
            myResult.getInt(6),
            myResult.getInt(7)
        );
        return qualityRow;
    }

    private AccountRow res_set_to_accounts(ResultSet myResult) throws Exception  {
        AccountRow accountRow = new AccountRow(
                myResult.getInt(1),
                myResult.getString(2),
                myResult.getString(3),
                myResult.getInt(4),
                myResult.getInt(5)
        );
        return accountRow;
    }

    private ProductRow res_set_to_products(ResultSet myResult) throws Exception  {
        ProductRow productRow = new ProductRow(
            myResult.getInt(1),
            myResult.getString(2),
            myResult.getInt(3),
            myResult.getInt(4),
            myResult.getInt(5)
        );

        return productRow;
    }

    private StoreRow res_set_to_stores(ResultSet myResult) throws Exception  {
        StoreRow storeRow = new StoreRow(
            myResult.getInt(1),
            myResult.getString(2),
            myResult.getString(3)
        );
        return storeRow;
    }

    private WorkerRow res_set_to_workers(ResultSet myResult) throws Exception  {
        WorkerRow workerRow = new WorkerRow(
            myResult.getInt(1),
            myResult.getString(2),
            myResult.getString(3),
            myResult.getInt(4),
            myResult.getInt(5)
        );
        return workerRow;
    }
}
