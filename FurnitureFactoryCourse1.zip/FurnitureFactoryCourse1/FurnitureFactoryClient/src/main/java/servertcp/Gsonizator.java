package servertcp;


import entities.*;
import com.google.gson.reflect.TypeToken;
import sistem.Serializer;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class Gsonizator {
    private final static String hostName = "localhost";
    private final static int portName = 2020;
    private static Gsonizator serverConnector;
    private ObjectOutputStream strimToOut;
    private ObjectInputStream strimToIn;
    private java.net.Socket socketClientToServer;
    public boolean isWeHaveAProblem;

    public void getAccepted(){
        isWeHaveAProblem = false;
        try {
            socketClientToServer = new java.net.Socket(hostName, portName);
            strimToOut = new ObjectOutputStream(socketClientToServer.getOutputStream());
            strimToIn = new ObjectInputStream(socketClientToServer.getInputStream());
        } catch(Exception e){
            isWeHaveAProblem = true;
        }
    }

    public String exitFromTCPConnection(){
        try {
            executeThisCommand("exit", "");
            closeAll();
            return "";
        } catch (Exception e){
            return "Ошибка работы программы!\n разсоединения!";
        }
    }

    private void closeAll() throws IOException {
        strimToIn.close();
        strimToOut.close();
        socketClientToServer.close();
    }




    public String executeThisCommand(String thisClientCommand, String data){
        try {
            strimToOut.writeObject(thisClientCommand);
            strimToOut.writeObject(data);
            isWeHaveAProblem = false;

            return strimToIn.readObject().toString();
        } catch (Exception e){
            isWeHaveAProblem = true;
            return "";
        }

    }

    public final static String goGetConnection(){
        serverConnector = new Gsonizator();
        serverConnector.getAccepted();
        return serverConnector.isWeHaveAProblem ? "Ошибка работы программы!\n подключения" : "";
    }

    public final static AccountRow checkAuthorization(AccountRow worker) {
        String workerJSON = Serializer.gsonizate(worker), thisClientCommand = "authorization", answer;
        answer = serverConnector.executeThisCommand(thisClientCommand, workerJSON);
        return  !("".equals(answer)) ? (AccountRow) Serializer.degsonizate(answer, AccountRow.class) : null;
    }


    public final static ArrayList<AbstractRow> SelectAccountRows(String stringToOrderBy, String stringToWhere){
        String answer = SelectModels("select_accounts", stringToOrderBy, stringToWhere);
        return !("".equals(answer)) ? Serializer.degsonizates(answer, new TypeToken<ArrayList<AccountRow>>(){}.getType()) : null;
    }

    public final static ArrayList<AbstractRow> SelectQualityRows(String stringToOrderBy, String stringToWhere){
        String answer = SelectModels("select_qualitys", stringToOrderBy, stringToWhere);
        return !("".equals(answer)) ? Serializer.degsonizates(answer, new TypeToken<ArrayList<QualityRow>>(){}.getType()) : null;
    }

    public final static ArrayList<AbstractRow> SelectProductRows(String stringToOrderBy, String stringToWhere){
        String answer = SelectModels("select_products", stringToOrderBy, stringToWhere);
        return !("".equals(answer)) ? Serializer.degsonizates(answer, new TypeToken<ArrayList<ProductRow>>(){}.getType()) : null;
    }

    public final static ArrayList<AbstractRow> SelectStoreRows(String stringToOrderBy, String stringToWhere){
        String answer = SelectModels("select_stores", stringToOrderBy, stringToWhere);
        return !("".equals(answer)) ? Serializer.degsonizates(answer, new TypeToken<ArrayList<StoreRow>>(){}.getType()) : null;
    }

    public final static ArrayList<AbstractRow> SelectWorkers(String stringToOrderBy, String stringToWhere){
        String answer = SelectModels("select_workers", stringToOrderBy, stringToWhere);
        if(!("".equals(answer))) {
            return Serializer.degsonizates(answer, new TypeToken<ArrayList<WorkerRow>>() {}.getType());
        }
        else {
            return null;
        }

    }

    private final static String SelectModels(String thisClientCommand, String stringToOrderBy, String stringToWhere) {
        String data = "";
        if(!stringToOrderBy.trim().equals("") || !stringToWhere.trim().equals("")) {
            data = stringToOrderBy + " ~~~~~ " + stringToWhere;
        }
        return serverConnector.executeThisCommand(thisClientCommand, data);
    }


    public final static boolean insert(AbstractRow abstractRow, String table){
        String thisClientCommand = "insert_", data = Serializer.gsonizate(abstractRow);
        if("".equals(serverConnector.executeThisCommand(thisClientCommand + table, data)))
            return false;
        else
            return true;
    }

    public final static boolean update(AbstractRow abstractRow, String table, int id){
        String thisClientCommand = "update_", data = Serializer.gsonizate(abstractRow) + "~~~~~" + id;
        if("".equals(serverConnector.executeThisCommand(thisClientCommand + table, data)))
            return false;
        else
            return true;
    }

    public final static boolean delete(int id, String table){
        String thisClientCommand = "delete", data = table + "~~~~~" + id;
        if("".equals(serverConnector.executeThisCommand(thisClientCommand, data)))
            return false;
        else
            return true;
    }

    public static String exit( ){
        return serverConnector.exitFromTCPConnection();
    }


}
