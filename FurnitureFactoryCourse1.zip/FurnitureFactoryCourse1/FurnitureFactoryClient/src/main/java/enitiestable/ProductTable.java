package enitiestable;

import entities.ProductRow;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class ProductTable extends AbstractTableModel {
    private ArrayList<ProductRow> products;


    public ProductTable(ArrayList<ProductRow> models ) {
        super();
        this.products = models;
    }

    @Override
    public int getRowCount() {
        return products.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column){
            default:case 0: return products.get(row).id;
            case 1: return products.get(row).name;
            case 2: return products.get(row).price;
            case 3: return products.get(row).self_price;
            case 4: return products.get(row).store_id;
        }
    }

    @Override
    public String getColumnName(int column) {
        return ProductRow.ColumnsThisTable[column];
    }
}
