package enitiestable;

import entities.StoreRow;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class StoreTable extends AbstractTableModel {
    private ArrayList<StoreRow> stores;

    public ArrayList<StoreRow> getstores() {
        return stores;
    }

    public StoreTable(ArrayList<StoreRow> stores) {
        super();
        this.stores = stores;
    }


    @Override
    public int getRowCount() {
        return stores.size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column){
            default:case 0: return stores.get(row).id;
            case 1: return stores.get(row).name;
            case 2: return stores.get(row).adress;
        }
    }

    @Override
    public String getColumnName(int column) {
        return StoreRow.ColumnsThisTable[column];
    }

}
