package enitiestable;

import entities.QualityRow;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class QualityTable extends AbstractTableModel {
    private ArrayList<QualityRow> qualitys;


    public QualityTable(ArrayList<QualityRow> models ) {
        super();
        this.qualitys = models;
    }

    @Override
    public int getRowCount() {
        return qualitys.size();
    }

    @Override
    public int getColumnCount() {
        return 7;
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column){
            default:case 0: return qualitys.get(row).id;
            case 1: return qualitys.get(row).name;
            case 2: return qualitys.get(row).category;
            case 3: return qualitys.get(row).point;
            case 4: return qualitys.get(row).point_buyers;
            case 5: return qualitys.get(row).product_id;
            case 6: return qualitys.get(row).importance;
        }
    }

    @Override
    public String getColumnName(int column) {
        return QualityRow.ColumnsThisTable[column];
    }
}
