package enitiestable;

import entities.AccountRow;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class AccountTable extends AbstractTableModel {
    private ArrayList<AccountRow> accounts;

    public AccountTable(ArrayList<AccountRow> models ) {
        super();
        this.accounts = models;
    }

    @Override
    public int getRowCount() {
        return accounts.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column){
            default:case 0: return accounts.get(row).id;
            case 1: return accounts.get(row).login;
            case 2: return accounts.get(row).password;
            case 3: return accounts.get(row).accountRole;
            case 4: return accounts.get(row).worker_id;
        }
    }

    @Override
    public String getColumnName(int column) {
        return AccountRow.ColumnsThisTable[column];
    }

}
