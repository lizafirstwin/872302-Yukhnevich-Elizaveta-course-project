package enitiestable;


import entities.WorkerRow;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class WorkerTable extends AbstractTableModel {
    private ArrayList<WorkerRow> workers;


    public WorkerTable(ArrayList<WorkerRow> models) {
        super();
        this.workers = models;
    }

    @Override
    public int getRowCount() {
        return workers.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column){
            default:case 0: return workers.get(row).id;
            case 1: return workers.get(row).firstName;
            case 2: return workers.get(row).lastName;
            case 3: return workers.get(row).experience;
            case 4: return workers.get(row).store_id;
        }
    }

    @Override
    public String getColumnName(int column) {
        return WorkerRow.ColumnsThisTable[column];
    }

}
