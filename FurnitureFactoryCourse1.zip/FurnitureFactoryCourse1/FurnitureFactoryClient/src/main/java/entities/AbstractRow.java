package entities;

public interface AbstractRow {
    public int getId();
}
