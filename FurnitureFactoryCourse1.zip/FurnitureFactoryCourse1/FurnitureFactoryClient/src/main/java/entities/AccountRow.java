package entities;

public class AccountRow implements AbstractRow {
    public final static String[] ColumnsThisTable = {"id", "login", "password", "accountRole", "worker_id"};
    public final static boolean[] IsInegerCol = {true, false, false, true, true};

    public int id;
    public String login;
    public String password;
    public int accountRole;
    public int worker_id;

    @Override
    public int getId() {
        return id;
    }

    public AccountRow(int id, String login, String password, int accountRole, int worker_id){
        this.id = id;
        this.login = login;
        this.password = password;
        this.accountRole = accountRole;
        this.worker_id = worker_id;
    }

    public AccountRow(){}
}