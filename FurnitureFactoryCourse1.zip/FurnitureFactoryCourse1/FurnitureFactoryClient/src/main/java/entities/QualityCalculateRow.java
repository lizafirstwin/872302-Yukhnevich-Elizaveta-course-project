package entities;

public class QualityCalculateRow implements AbstractRow {
    public final static String[] ColumnsThisTable = {"id", "name", "point", "price"};


    public int id;
    public String name;
    public double point;
    public int price;
    public int self_price;

    @Override
    public int getId() {
        return id;
    }

    public QualityCalculateRow(int id, String name,double point, int price, int self_price){
        this.id = id;
        this.name = name;
        this.point = point;
        this.price = price;
        this.self_price = self_price;
    }

}
