package entities;

public class ProductRow implements AbstractRow {
    public final static String[] ColumnsThisTable = {"id", "name", "price", "self_price", "store_id"};
    public final static boolean[] IsInegerCol = {true, false, true, true, true};

    public int id;
    public String name;
    public int price;
    public int self_price;
    public int store_id;

    @Override
    public int getId() {
        return id;
    }

    public ProductRow(int id, String name, int price, int self_price, int store_id){
        this.id = id;
        this.name = name;
        this.price = price;
        this.self_price = self_price;
        this.store_id = store_id;
    }

}
