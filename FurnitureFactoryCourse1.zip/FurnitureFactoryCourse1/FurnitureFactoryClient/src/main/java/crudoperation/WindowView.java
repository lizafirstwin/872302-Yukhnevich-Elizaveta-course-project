package crudoperation;


import guielements.WindowCreator;
import guielements.WindowAuthenticate;
import servertcp.Gsonizator;
import enitiestable.*;
import entities.*;
import sistem.Transformator;

import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;


public class WindowView {
    private WindowCreator searchingDataDialog;
    private WindowCreator sortingDataDialog;
    private WindowCreator tableDialogDialog;
    private String stringToWhere = "";
    private Class<? extends AbstractRow> thisClass;

    public WindowView(WindowCreator tableDialogDialog, Class<? extends AbstractRow> thisClass){
        this.tableDialogDialog = tableDialogDialog;
        this.thisClass = thisClass;
    }

    public void goGetSort() {
        sortingDataDialog = new WindowCreator("Сортируем данные", 300, 200);

        sortingDataDialog.addLabel(200, 40,50, 10, "По полю:");
        sortingDataDialog.addComboBox(false,200, 40,50, 40);
        sortingDataDialog.addButton(200,40,50, 90, "Сортируем!");
        prepareDeffData();

        sortingDataDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        sortingDataDialog.setVisible(true);
    }

    private void prepareDeffData(){
        getColumns(sortingDataDialog);
        addListenerSort();
    }

    private void addListenerSort(){
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                findMeMoreData(sortingDataDialog.ThisLists.get(0).getSelectedItem().toString());
                sortingDataDialog.dispose();
            }
        };
        sortingDataDialog.ThisButtons.get(0).addActionListener(actionListener);
    }

    public void goGetSearch() {
        searchingDataDialog = new WindowCreator("Поиск", 350, 270);

        searchingDataDialog.addLabel(250, 40,30, 10, "По полю:");
        searchingDataDialog.addComboBox(false,250, 40,30, 40);
        searchingDataDialog.addLabel(250, 40,30, 90, "Ищем:");
        searchingDataDialog.addTextField(250, 40,30, 120, "1");
        searchingDataDialog.addButton(250, 40,30, 170, "Ищем!");
        prepareUnData();

        searchingDataDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        searchingDataDialog.setVisible(true);
    }

    private void prepareUnData(){
        getColumns(searchingDataDialog);
        addListenerSearch();
    }

    private void addListenerSearch(){
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                chosestringToWhereStr();
                if(!choseMessageOk()) return;
                findMeMoreData("");
                searchingDataDialog.dispose();
            }
        };
        searchingDataDialog.ThisButtons.get(0).addActionListener(actionListener);
    }

    private void chosestringToWhereStr(){
        String apos = "";
        switch (thisClass.getName()) {
            case "entities.AccountRow":
                apos = trainingstringToWhereString(AccountRow.ColumnsThisTable, AccountRow.IsInegerCol); break;
            case "entities.QualityRow":
                apos = trainingstringToWhereString(QualityRow.ColumnsThisTable, QualityRow.IsInegerCol); break;
            case "entities.ProductRow":
                apos = trainingstringToWhereString(ProductRow.ColumnsThisTable, ProductRow.IsInegerCol); break;
            case "entities.StoreRow":
                apos = trainingstringToWhereString(StoreRow.ColumnsThisTable, StoreRow.IsInegerCol); break;
            case "entities.WorkerRow":
                apos = trainingstringToWhereString(WorkerRow.ColumnsThisTable, WorkerRow.IsInegerCol); break;
        }
        stringToWhere += " = " + apos + searchingDataDialog.ThisFields.get(0).getText() + apos;
    }

    private String trainingstringToWhereString(String cols[], boolean integerCheck[]){
        stringToWhere = searchingDataDialog.ThisLists.get(0).getSelectedItem().toString();
        for (int i = 0; i < cols.length; i++) {
            if(stringToWhere.equals(cols[i])) {
                if(!integerCheck[i]) return "'";
                else return "";
            }
        }
        return "";
    }


    private boolean choseMessageOk(){
        switch (thisClass.getName()) {
            case "entities.AccountRow":     return isGoodInt(AccountRow.IsInegerCol);
            case "entities.QualityRow":      return isGoodInt(QualityRow.IsInegerCol);
            case "entities.ProductRow":     return isGoodInt(ProductRow.IsInegerCol);
            case "entities.StoreRow":     return isGoodInt(StoreRow.IsInegerCol);
            case "entities.WorkerRow":         return isGoodInt(WorkerRow.IsInegerCol);
            default: return false;
        }
    }

    private boolean isGoodInt(boolean isStr[]){
        int selecterIndex = searchingDataDialog.ThisLists.get(0).getSelectedIndex();
        boolean integerCheckColumns = selecterIndex == 0;
        for (int i = 0; i < isStr.length; i++) {
            if(!isStr[i]){
                integerCheckColumns = integerCheckColumns || selecterIndex == i+1;
            }
        }

        return checking(integerCheckColumns);
    }



    private boolean checking(boolean integerCheckColumns){
        if(integerCheckColumns) {
            if (!WindowAuthenticate.integerCheck(searchingDataDialog.ThisFields.get(0).getText())) {
                messageError();
                return false;
            }
        }
        return true;
    }
    private void messageError(){
        String mes = "Введено не целое число для int-вого поля!";
        JOptionPane.showMessageDialog(searchingDataDialog, mes, "Ошибка!", JOptionPane.PLAIN_MESSAGE);
    }

    protected void getColumns(WindowCreator dialog){
        switch (thisClass.getName()) {
            case "entities.AccountRow":     addDefCols(dialog, AccountRow.ColumnsThisTable); break;
            case "entities.QualityRow":      addDefCols(dialog, QualityRow.ColumnsThisTable); break;
            case "entities.ProductRow":     addDefCols(dialog, ProductRow.ColumnsThisTable); break;
            case "entities.StoreRow":     addDefCols(dialog, StoreRow.ColumnsThisTable); break;
            case "entities.WorkerRow":         addDefCols(dialog, WorkerRow.ColumnsThisTable); break;
        }
    }

    private void addDefCols(WindowCreator dialog, String items[]){
        for (int i = 0; i < items.length; i++) {
            dialog.ThisLists.get(0).addItem(items[i]);
        }
    }

    protected void findMeMoreData(String order){
        switch (thisClass.getName()) {
            case "entities.AccountRow":     selectAccountRow(order); break;
            case "entities.QualityRow":      selectQualityRow(order); break;
            case "entities.ProductRow":     selectProductRow(order); break;
            case "entities.StoreRow":     selectStoreRow(order); break;
            case "entities.WorkerRow":         selectWorker(order); break;
        }
    }

    private void selectAccountRow(String stringToOrderBy){
        ArrayList<AbstractRow> result;
        if((result = Gsonizator.SelectAccountRows(stringToOrderBy, stringToWhere)) == null){
            JOptionPane.showMessageDialog(tableDialogDialog, "Ошибвка сортировки!", "Ошибка!", JOptionPane.PLAIN_MESSAGE);
        } else {
            tableDialogDialog.ThisTable.get(0).setModel(new AccountTable(Transformator.getAccountToAutor(result)));
        }
    }

    private void selectQualityRow(String stringToOrderBy){
        ArrayList<AbstractRow> result;
        if((result = Gsonizator.SelectQualityRows(stringToOrderBy, stringToWhere)) == null){
            JOptionPane.showMessageDialog(tableDialogDialog, "Ошибвка сортировки!", "Ошибка!", JOptionPane.PLAIN_MESSAGE);
        } else {
            tableDialogDialog.ThisTable.get(0).setModel(new QualityTable(Transformator.toQualityRow(result)));
        }
    }


    private void selectProductRow(String stringToOrderBy){
        ArrayList<AbstractRow> result;
        if((result = Gsonizator.SelectProductRows(stringToOrderBy, stringToWhere)) == null){
            JOptionPane.showMessageDialog(tableDialogDialog, "Ошибвка сортировки!", "Ошибка!", JOptionPane.PLAIN_MESSAGE);
        } else {
            tableDialogDialog.ThisTable.get(0).setModel(new ProductTable(Transformator.toProductRow(result)));
        }
    }


    private void selectStoreRow(String stringToOrderBy){
        ArrayList<AbstractRow> result;
        if((result = Gsonizator.SelectStoreRows(stringToOrderBy, stringToWhere)) == null){
            JOptionPane.showMessageDialog(tableDialogDialog, "Ошибвка сортировки!", "Ошибка!", JOptionPane.PLAIN_MESSAGE);
        } else {
            tableDialogDialog.ThisTable.get(0).setModel(new StoreTable(Transformator.toStoreRow(result)));
        }
    }

    private void selectWorker(String stringToOrderBy){
        ArrayList<AbstractRow> result;
        if((result = Gsonizator.SelectWorkers(stringToOrderBy, stringToWhere)) == null){
            JOptionPane.showMessageDialog(tableDialogDialog, "Ошибвка сортировки!", "Ошибка!", JOptionPane.PLAIN_MESSAGE);
        } else {
            tableDialogDialog.ThisTable.get(0).setModel(new WorkerTable(Transformator.toWorker(result)));
        }
    }

}
