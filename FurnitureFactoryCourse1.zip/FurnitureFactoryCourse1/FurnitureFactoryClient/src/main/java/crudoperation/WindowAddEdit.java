package crudoperation;

import guielements.WindowCRUD;
import guielements.WindowCreator;
import guielements.WindowAuthenticate;
import servertcp.Gsonizator;
import entities.*;

import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class WindowAddEdit {
    private WindowCreator editWindow;
    protected WindowCreator currentDataTable;
    protected Class<? extends AbstractRow> thisClass;
    protected ArrayList<AbstractRow> rowsFromTable;
    protected WindowCRUD windowCRUD;

    public WindowAddEdit(WindowCreator currentDataTable, Class<? extends AbstractRow> thisClass, ArrayList<AbstractRow> rowsFromTable, WindowCRUD windowCRUD){
        this.currentDataTable = currentDataTable;
        this.thisClass = thisClass;
        this.rowsFromTable = WindowCRUD.updateData(this.thisClass, this.currentDataTable);
        this.windowCRUD = windowCRUD;
    }

    public void goGet(String thisClientCommand) {
        boolean isEditCommand;
        isEditCommand = (thisClientCommand == "ДОБАВИТЬ") ? false : true;
        if(!isWeHaveAProblem(isEditCommand)) return;
        createDialog(isEditCommand);
    }

    private boolean isWeHaveAProblem(boolean isEditCommand){
        if(isEditCommand  && currentDataTable.ThisTable.get(0).getSelectedRowCount() < 1) {
            JOptionPane.showMessageDialog(currentDataTable, "Не выбран элемент\n Выберите!");
            return false;
        }
        return true;
    }

    private void createDialog(boolean isEditCommand){
        trainingAddData();
        if (isEditCommand) selectedDataAdding();
        newEventAdd(isEditCommand);
        editWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        editWindow.setVisible(true);
    }


    protected void trainingAddData(){
        editWindow = new WindowCreator("Добавить\\Изменить данные!", 400, 350);

        int i;
        String columns[] = getColumns();
        for (i = 1; i < columns.length; i++) {
            setOneAdderString(i, columns[i]);
        }

        editWindow.addButton(200, 40,30, 90+(i-2)*80, "Добавить");
        editWindow.setSize(270, 180+(i-2)*80);
    }

    private void setOneAdderString(int i, String title){
        editWindow.addLabel(200, 40,50, 10 + (i-1)*80, title);
        editWindow.addTextField(200, 40,30, 40 + (i-1)*80, "");
    }

    private String[] getColumns(){
        switch (thisClass.getName()) {
            default:
            case "entities.AccountRow":     return AccountRow.ColumnsThisTable;
            case "entities.QualityRow":      return QualityRow.ColumnsThisTable;
            case "entities.ProductRow":     return ProductRow.ColumnsThisTable;
            case "entities.StoreRow":     return StoreRow.ColumnsThisTable;
            case "entities.WorkerRow":         return WorkerRow.ColumnsThisTable;
        }
    }

    protected void selectedDataAdding(){
        String stringToWhere = "id = " + WindowCRUD.findMeMoreData(thisClass).get(currentDataTable.ThisTable.get(0).getSelectedRow()).getId();

        ArrayList<AbstractRow> result = findMeMoreData(stringToWhere);
        if(result == null){
            JOptionPane.showMessageDialog(editWindow, "Ошибка поиска!", "Попробуйте попозже!!!", JOptionPane.PLAIN_MESSAGE);
            editWindow.dispose();
        }
        AbstractRow abstractRow = result.get(0);
        addOneLastData(abstractRow);
    }

    private ArrayList<AbstractRow> findMeMoreData(String stringToWhere){
        switch (thisClass.getName()) {
            case "entities.AccountRow":     return Gsonizator.SelectAccountRows("", stringToWhere);
            case "entities.QualityRow":      return Gsonizator.SelectQualityRows("", stringToWhere);
            case "entities.ProductRow":     return Gsonizator.SelectProductRows("", stringToWhere);
            case "entities.StoreRow":     return Gsonizator.SelectStoreRows("", stringToWhere);
            case "entities.WorkerRow":         return Gsonizator.SelectWorkers("", stringToWhere);
            default: return null;
        }
    }

    private void addOneLastData(AbstractRow abstractRow){
        switch (thisClass.getName()) {
            case "entities.AccountRow":          selectedAccountRow((AccountRow) abstractRow);               break;
            case "entities.QualityRow":         selectedQualityRow((QualityRow) abstractRow);             break;
            case "entities.ProductRow":     selectedProductRow((ProductRow) abstractRow);     break;
            case "entities.StoreRow":      selectedStoreRow((StoreRow) abstractRow);       break;
            case "entities.WorkerRow":          selectedWorker((WorkerRow) abstractRow);               break;
        }
    }

    private void selectedAccountRow(AccountRow model) {
        editWindow.ThisFields.get(0).setText(model.login);
        editWindow.ThisFields.get(1).setText(model.password);
        editWindow.ThisFields.get(2).setText(String.valueOf(model.accountRole));
        editWindow.ThisFields.get(3).setText(String.valueOf(model.worker_id));
    }

    private void selectedQualityRow(QualityRow model) {
        editWindow.ThisFields.get(0).setText(model.name);
        editWindow.ThisFields.get(1).setText(model.category);
        editWindow.ThisFields.get(2).setText(String.valueOf(model.point));
        editWindow.ThisFields.get(3).setText(String.valueOf(model.point_buyers));
        editWindow.ThisFields.get(4).setText(String.valueOf(model.product_id));
        editWindow.ThisFields.get(5).setText(String.valueOf(model.importance));
    }

    private void selectedProductRow(ProductRow model) {
        editWindow.ThisFields.get(0).setText(model.name);
        editWindow.ThisFields.get(1).setText(String.valueOf(model.price));
        editWindow.ThisFields.get(2).setText(String.valueOf(model.self_price));
        editWindow.ThisFields.get(3).setText(String.valueOf(model.store_id));
    }

    private void selectedStoreRow(StoreRow model) {
        editWindow.ThisFields.get(0).setText(model.name);
        editWindow.ThisFields.get(1).setText(String.valueOf(model.adress));
    }

    private void selectedWorker(WorkerRow model) {
        editWindow.ThisFields.get(0).setText(model.firstName);
        editWindow.ThisFields.get(1).setText(model.lastName);
        editWindow.ThisFields.get(2).setText(String.valueOf(model.experience));
        editWindow.ThisFields.get(3).setText(String.valueOf(model.store_id));
    }



    protected void newEventAdd(boolean isEditCommand){
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(changeAndCheckOk()){
                    goStarted();
                }
            }

            private void goStarted(){
                addData(isEditCommand, generateNewModel());
                windowCRUD.updateData(thisClass, currentDataTable);
                editWindow.dispose();
            }
        };
        editWindow.ThisButtons.get(0).addActionListener(actionListener);
    }

    private void addData(boolean isEditCommand, AbstractRow abstractRow){
        if(isEditCommand) goUpdate(abstractRow);
        else goInsert(abstractRow);

    }


    private void goUpdate(AbstractRow abstractRow){
        int id = rowsFromTable.get(currentDataTable.ThisTable.get(0).getSelectedRow()).getId();
        if (!Gsonizator.update(abstractRow, WindowCRUD.getCurrentTable(thisClass), id)) {
            JOptionPane.showMessageDialog(editWindow, "Ошибка редактирования!");
        }
    }

    private void goInsert(AbstractRow abstractRow){
        if (!Gsonizator.insert(abstractRow, WindowCRUD.getCurrentTable(thisClass))) {
            JOptionPane.showMessageDialog(editWindow, "Ошибка добавления!");
        }
    }

    private AbstractRow generateNewModel(){
        switch (thisClass.getName()) {
            default:
            case "entities.AccountRow":     return createAccountRow();
            case "entities.QualityRow":      return createQualityRow();
            case "entities.ProductRow":     return createProductRow();
            case "entities.StoreRow":     return createStoreRow();
            case "entities.WorkerRow":         return createWorker();
        }
    }

    private AbstractRow createAccountRow () {
        AccountRow model = new AccountRow(
                0,
                editWindow.ThisFields.get(0).getText(),
                editWindow.ThisFields.get(1).getText(),
                Integer.valueOf(editWindow.ThisFields.get(2).getText()),
                Integer.valueOf(editWindow.ThisFields.get(3).getText())
        );
        return (AbstractRow) model;
    }

    private AbstractRow createQualityRow() {
        QualityRow model = new QualityRow(
                0,
                editWindow.ThisFields.get(0).getText(),
                editWindow.ThisFields.get(1).getText(),
                Integer.valueOf(editWindow.ThisFields.get(2).getText()),
                Integer.valueOf(editWindow.ThisFields.get(3).getText()),
                Integer.valueOf(editWindow.ThisFields.get(4).getText()),
                Integer.valueOf(editWindow.ThisFields.get(5).getText())
        );
        return (AbstractRow) model;
    }

    private AbstractRow createProductRow() {
        ProductRow model = new ProductRow(
                0,
                editWindow.ThisFields.get(0).getText(),
                Integer.valueOf(editWindow.ThisFields.get(1).getText()),
                Integer.valueOf(editWindow.ThisFields.get(2).getText()),
                Integer.valueOf(editWindow.ThisFields.get(3).getText())
        );
        return (AbstractRow) model;
    }

    private AbstractRow createStoreRow() {
        StoreRow model = new StoreRow(
                0,
                editWindow.ThisFields.get(0).getText(),
                editWindow.ThisFields.get(1).getText()
        );
        return (AbstractRow) model;
    }

    private AbstractRow createWorker() {
        WorkerRow model = new WorkerRow(
                0,
                editWindow.ThisFields.get(0).getText(),
                editWindow.ThisFields.get(1).getText(),
                Integer.valueOf(editWindow.ThisFields.get(2).getText()),
                Integer.valueOf(editWindow.ThisFields.get(3).getText())
        );
        return (AbstractRow) model;
    }

    private boolean changeAndCheckOk(){
        switch (thisClass.getName()) {
            case "entities.AccountRow":     return checkAddOk(AccountRow.ColumnsThisTable, AccountRow.IsInegerCol);
            case "entities.QualityRow":      return checkAddOk(QualityRow.ColumnsThisTable, QualityRow.IsInegerCol);
            case "entities.ProductRow":     return checkAddOk(ProductRow.ColumnsThisTable, ProductRow.IsInegerCol);
            case "entities.StoreRow":     return checkAddOk(StoreRow.ColumnsThisTable, StoreRow.IsInegerCol);
            case "entities.WorkerRow":         return checkAddOk(WorkerRow.ColumnsThisTable, WorkerRow.IsInegerCol);
            default: return false;
        }
    }

    private boolean checkAddOk(String columns[], boolean integerCheckColumns[]){
        String answer = "";
        for (int i = 1; i < integerCheckColumns.length; i++) {
            if(!integerCheckColumns[i]){
                if("".equals(editWindow.ThisFields.get(i-1).getText().trim())){
                    answer += columns[i] + " не заполнено данными!\r\n";
                }
            }  else {
                if(!WindowAuthenticate.integerCheck(editWindow.ThisFields.get(i-1).getText())){
                    answer += columns[i] + " не является числом!\r\n";
                }
            }
        }

        if(!answer.equals("")) JOptionPane.showMessageDialog(editWindow, "Ошибки:\r\n" + answer, "Ошика!!!", JOptionPane.PLAIN_MESSAGE);
        return answer.equals("") ? true : false;
    }



}
