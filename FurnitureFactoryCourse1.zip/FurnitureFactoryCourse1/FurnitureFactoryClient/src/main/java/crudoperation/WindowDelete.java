package crudoperation;

import guielements.WindowCRUD;
import guielements.WindowCreator;
import servertcp.Gsonizator;
import entities.AbstractRow;

import javax.swing.*;

public class WindowDelete {
    private WindowCreator currentDataTable;
    private Class<? extends AbstractRow> thisClass;
    private WindowCRUD windowCRUD;

    public WindowDelete(WindowCreator currentDataTable, Class<? extends AbstractRow> thisClass, WindowCRUD windowCRUD){
        this.currentDataTable = currentDataTable;
        this.thisClass = thisClass;
        this.windowCRUD = windowCRUD;
    }

    public void goGet() {
        if(currentDataTable.ThisTable.get(0).getSelectedRowCount() < 1) {
            JOptionPane.showMessageDialog(currentDataTable, "Не выбран элемент\n Выберите!");
            return;
        }
        int id = WindowCRUD.findMeMoreData(thisClass).get(currentDataTable.ThisTable.get(0).getSelectedRow()).getId();
        delete(id);
        windowCRUD.updateData(thisClass, currentDataTable);
    }

    private void delete(int id){
        if(!Gsonizator.delete(id, WindowCRUD.getCurrentTable(thisClass))) {
            JOptionPane.showMessageDialog(currentDataTable, "Ошибка удаления!\n Попытайтесь позже!");
        }
    }


}
