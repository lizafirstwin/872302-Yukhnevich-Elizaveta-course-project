package sistem;

import entities.AbstractRow;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class Serializer {
    public static String gsonizate(AbstractRow abstractRow) {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        return gson.toJson(abstractRow);
    }

    public static AbstractRow degsonizate(String string, Class<? extends AbstractRow> modelType) {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        return gson.fromJson(string, modelType);
    }

    public static ArrayList<AbstractRow> degsonizates(String string, Type type) {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        return gson.fromJson(string, type);
    }
}
