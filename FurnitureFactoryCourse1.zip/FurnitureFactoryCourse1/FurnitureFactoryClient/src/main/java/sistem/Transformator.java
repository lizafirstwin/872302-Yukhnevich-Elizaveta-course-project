package sistem;

import entities.*;

import java.util.ArrayList;

public class Transformator {
    public static ArrayList<AccountRow> getAccountToAutor(ArrayList<AbstractRow> rowsFromTable){
        if(rowsFromTable == null) return null;
        ArrayList<AccountRow> AccountRows = new ArrayList<>();
        AccountRows = convertAccountRow(AccountRows, rowsFromTable);
        return AccountRows;
    }

    private static ArrayList<AccountRow> convertAccountRow(ArrayList<AccountRow> AccountRows, ArrayList<AbstractRow> rowsFromTable){
        for (int i = 0; i < rowsFromTable.size(); i++) {
            AccountRows.add((AccountRow) rowsFromTable.get(i));
        }
        return AccountRows;
    }

    public static ArrayList<QualityRow> toQualityRow(ArrayList<AbstractRow> rowsFromTable){
        if(rowsFromTable == null) return null;

        ArrayList<QualityRow> QualityRows = new ArrayList<>();
        QualityRows = convertQualityRow(QualityRows, rowsFromTable);

        return QualityRows;
    }


    private static ArrayList<QualityRow> convertQualityRow(ArrayList<QualityRow> QualityRows, ArrayList<AbstractRow> rowsFromTable){
        for (int i = 0; i < rowsFromTable.size(); i++) {
            QualityRows.add((QualityRow) rowsFromTable.get(i));
        }
        return QualityRows;
    }

    public static ArrayList<ProductRow> toProductRow(ArrayList<AbstractRow> rowsFromTable){
        if(rowsFromTable == null) return null;

        ArrayList<ProductRow> ProductRows = new ArrayList<>();
        ProductRows = convertProductRow(ProductRows, rowsFromTable);

        return ProductRows;
    }

    private static ArrayList<ProductRow> convertProductRow(ArrayList<ProductRow> ProductRows, ArrayList<AbstractRow> rowsFromTable){
        for (int i = 0; i < rowsFromTable.size(); i++) {
            ProductRows.add((ProductRow) rowsFromTable.get(i));
        }
        return ProductRows;
    }

    public static ArrayList<StoreRow> toStoreRow(ArrayList<AbstractRow> rowsFromTable){
        if(rowsFromTable == null) return null;

        ArrayList<StoreRow> StoreRows = new ArrayList<>();
        StoreRows = convertStoreRow(StoreRows, rowsFromTable);

        return StoreRows;
    }


    private static ArrayList<StoreRow> convertStoreRow(ArrayList<StoreRow> StoreRows, ArrayList<AbstractRow> rowsFromTable){
        for (int i = 0; i < rowsFromTable.size(); i++) {
            StoreRows.add((StoreRow) rowsFromTable.get(i));
        }
        return StoreRows;
    }

    public static ArrayList<WorkerRow> toWorker(ArrayList<AbstractRow> rowsFromTable){
        if(rowsFromTable == null) return null;

        ArrayList<WorkerRow> Workers = new ArrayList<>();
        Workers = convertWorkerRow(Workers, rowsFromTable);

        return Workers;
    }

    private static ArrayList<WorkerRow> convertWorkerRow(ArrayList<WorkerRow> Workers, ArrayList<AbstractRow> rowsFromTable){
        for (int i = 0; i < rowsFromTable.size(); i++) {
            Workers.add((WorkerRow) rowsFromTable.get(i));
        }
        return Workers;
    }

}
