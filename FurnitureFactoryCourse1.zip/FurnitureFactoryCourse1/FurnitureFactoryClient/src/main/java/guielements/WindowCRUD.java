package guielements;

import servertcp.Gsonizator;
import enitiestable.*;
import entities.*;
import crudoperation.WindowAddEdit;
import crudoperation.WindowDelete;
import crudoperation.WindowView;
import sistem.Transformator;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.AbstractTableModel;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;

public class WindowCRUD {

    private String headerText;
    private WindowCreator currentTableDialog;
    private Class<? extends AbstractRow> thisClass;
    private WindowCreator currentDataTable;
    private ArrayList<AbstractRow> rowsFromTable = new ArrayList<>();
    private int adminChecking;

    public WindowCRUD(Class<? extends AbstractRow> thisClass, WindowCreator currentDataTable, String headerText, int adminChecking){
        this.currentDataTable = currentDataTable;
        this.thisClass = thisClass;
        this.headerText = headerText;
        this.adminChecking = adminChecking;
    }

    public void create(){
        currentTableDialog = new WindowCreator(headerText, 660, 710);
        dialogInit();
        currentTableDialog.setVisible(true);
    }

    private void dialogInit(){
        addWindowListener();
        trainingDialog();
        setEventsForThisButtons();
    }


    private void addWindowListener(){
        currentTableDialog.addWindowListener(new WindowListener() {
            public void windowActivated(WindowEvent event) {}
            public void windowClosed(WindowEvent event) {}
            public void windowDeactivated(WindowEvent event) {}
            public void windowDeiconified(WindowEvent event) {}
            public void windowIconified(WindowEvent event) {}
            public void windowOpened(WindowEvent event) {
                currentDataTable.setVisible(false);
            }
            public void windowClosing(WindowEvent event) {
                currentDataTable.setVisible(true);
            }
        });
        currentTableDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    private void trainingDialog(){
        if((rowsFromTable = WindowCRUD.findMeMoreData(thisClass)) == null) {
            JOptionPane.showMessageDialog(currentTableDialog, "Ошибка работы программы!\n: данные не обнаружены!");
            currentTableDialog.dispose();
            return;
        }

        currentTableDialog.addButton(250, 40, 30, 10, "ПОИСК");
        currentTableDialog.addButton(250, 40,380, 10, "СОРТИРОВКА");
        currentTableDialog.addButton(250, 40,30, 60, "СБРОСИТЬ ФИЛЬТРЫ");
        if(adminChecking == 0) {
            addAdminData();
        }
        int y = adminChecking == 0 ? 110 : 60;
        int x = adminChecking == 0 ? 30 : 380;
        currentTableDialog.addButton(250, 40, x, y, "СОХРАНИТЬ");
        currentTableDialog.addTable(600, 400, 30, y+50, getModel(rowsFromTable, thisClass));
        if(thisClass.getName().equals("entities.QualityRow")){
            currentTableDialog.addLabel(150, 40, 30, y+460, "Бюджет копании:");
            currentTableDialog.addTextField(200, 40, 210, y+460, "11000");
            currentTableDialog.addButton(200, 40, 430, y+460, "РАСЧЁТ СТРАТЕГИИ");
            currentTableDialog.addButton(200, 40, 430, y+510, "ГРАФИК ОЦЕНОК");
        }

    }

    private void addAdminData(){
        currentTableDialog.addButton(250, 40, 380, 60, "ДОБАВИТЬ");
        currentTableDialog.addButton(250, 40, 30, 110, "РЕДАКТИРОВАТЬ");
        currentTableDialog.addButton(250, 40, 380, 110, "УДАЛИТЬ");
    }

    public static ArrayList<AbstractRow> findMeMoreData(Class<? extends AbstractRow> thisClass){
        switch (thisClass.getName()) {
            case "entities.AccountRow":     return Gsonizator.SelectAccountRows("", "");
            case "entities.QualityRow":      return Gsonizator.SelectQualityRows("", "");
            case "entities.ProductRow":     return Gsonizator.SelectProductRows("", "");
            case "entities.StoreRow":     return Gsonizator.SelectStoreRows("", "");
            case "entities.WorkerRow":         return Gsonizator.SelectWorkers("", "");
            default: return null;
        }
    }

    private static AbstractTableModel getModel(ArrayList<AbstractRow> abstractRow, Class<? extends AbstractRow> thisClass){
        switch (thisClass.getName()) {
            case "entities.AccountRow":     return new AccountTable(Transformator.getAccountToAutor(abstractRow));
            case "entities.QualityRow":      return new QualityTable(Transformator.toQualityRow(abstractRow));
            case "entities.ProductRow":     return new ProductTable(Transformator.toProductRow(abstractRow));
            case "entities.StoreRow":     return new StoreTable(Transformator.toStoreRow(abstractRow));
            case "entities.WorkerRow":         return new WorkerTable(Transformator.toWorker(abstractRow));
            default: return null;
        }
    }

    private void setEventsForThisButtons(){
        addAdmin();
        setEventSearch();
        setEventSort();
        setEventReset();
        setEventScrin(adminChecking);
        if(thisClass.getName().equals("entities.QualityRow")){
            addCalculateStrategy();
            addShowDiagram();
        }
    }

    private void addAdmin() {
        if(adminChecking == 0) {
            setEventAddRed();
            setEventDel();
        }
    }


    private void setEventAddRed(){
        WindowAddEdit beditWindow =  new WindowAddEdit(currentTableDialog, thisClass, rowsFromTable, this);
        ActionListener actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                beditWindow.goGet(e.getActionCommand());

            }
        };
        currentTableDialog.ThisButtons.get(3).addActionListener(actionListener);
        currentTableDialog.ThisButtons.get(4).addActionListener(actionListener);
    }

    private void setEventDel(){
        WindowDelete bdelListener =  new WindowDelete(currentTableDialog, thisClass, this);
        currentTableDialog.ThisButtons.get(5).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bdelListener.goGet();
            }
        });
    }

    private void setEventSearch(){
        WindowView WindowView =  new WindowView(currentTableDialog, thisClass );
        currentTableDialog.ThisButtons.get(0).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                WindowView.goGetSearch();
            }
        });
    }

    private void setEventSort(){
        WindowView WindowView =  new WindowView(currentTableDialog, thisClass);
        currentTableDialog.ThisButtons.get(1).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                WindowView.goGetSort();
            }
        });
    }

    private void setEventReset(){
        currentTableDialog.ThisButtons.get(2).addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                rowsFromTable = updateData(thisClass, currentTableDialog);
            }
        });
    }


    private void addCalculateStrategy(){
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(WindowAuthenticate.integerCheck(currentTableDialog.ThisFields.get(0).getText())){
                    int moneyAmount = Integer.valueOf(currentTableDialog.ThisFields.get(0).getText());
                    calculateStrategy(moneyAmount, getFileName());
                } else {
                    JOptionPane.showMessageDialog(currentDataTable, "Введите корректные данные!");
                }
            }
        };
        if(adminChecking == 0) currentTableDialog.ThisButtons.get(7).addActionListener(actionListener);
        else currentTableDialog.ThisButtons.get(4).addActionListener(actionListener);

    }

    private void addShowDiagram(){
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                WindowChart chart = new WindowChart(Transformator.toQualityRow(rowsFromTable));
            }
        };
        if(adminChecking == 0) currentTableDialog.ThisButtons.get(8).addActionListener(actionListener);
        else currentTableDialog.ThisButtons.get(5).addActionListener(actionListener);

    }

    private String getFileName() {
        final JFileChooser finder = new JFileChooser();
        finder.setDialogTitle("Сохранить отчёт по стратегии развития");
        finder.setFileFilter(new FileNameExtensionFilter("Text Files", "txt"));
        int returnVal = finder.showSaveDialog(null);
        if (returnVal == javax.swing.JFileChooser.APPROVE_OPTION) {
            java.io.File file = finder.getSelectedFile();
            return file.toString() + ".txt";
        } else {
            return "fileSomething.txt";
        }
    }

    private void calculateStrategy(int moneyAmount, String fileName){
        int quantityProduct = 0, amount = 0;
        ArrayList<QualityCalculateRow> products = getProducts();
        products = sortProducts(products);
        writeUsingFiles("Расчёт оптимальной стратегии производства\r\n", fileName, true);
        writeUsingFiles("На основе экспертных оценок:\r\n\r\n", fileName, false);
        for (QualityCalculateRow product :
                products) {
            int quantity = 0;
            if(product.price > product.self_price) {
                while (moneyAmount >= product.self_price) {
                    moneyAmount -= product.self_price;
                    amount += product.price - product.self_price;
                    quantity++;
                }
            }
            quantityProduct = quantity == 0 ? quantityProduct : quantityProduct + 1;
            if(quantity != 0)
                writeUsingFiles("Товар \"" + product.name + "\": " + quantity + "шт.\r\n", fileName, false);
        }
        if(quantityProduct == 0){
            writeUsingFiles("\r\nДенег не достаточно.. Закрывайтесь\r\n)", fileName, false);
        } else {
            writeUsingFiles("Итого выручка: " + amount + "\r\n", fileName, false);
        }
        JOptionPane.showMessageDialog(currentDataTable, "Отчёт сохранён в файл \"" + fileName + "\"!");
    }

    private static void writeUsingFiles(String data, String path, boolean isWrite) {
        try {
            if(isWrite)
                Files.write(Paths.get(path), data.getBytes());
            else
                Files.write(Paths.get(path), data.getBytes(), StandardOpenOption.APPEND);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private ArrayList<QualityCalculateRow> sortProducts(ArrayList<QualityCalculateRow> products) {
        for (int i = 0; i < products.size(); i++) {
            for (int j = i; j < products.size(); j++) {
                if(products.get(i).point < products.get(j).point){
                    QualityCalculateRow temp = new QualityCalculateRow(
                            products.get(i).id,
                            products.get(i).name,
                            products.get(i).point,
                            products.get(i).price,
                            products.get(i).self_price
                    );
                    products.get(i).id = products.get(j).id ;
                    products.get(i).name = products.get(j).name ;
                    products.get(i).point = products.get(j).point ;
                    products.get(i).price = products.get(j).price ;
                    products.get(i).self_price = products.get(j).self_price ;
                    products.set(j, temp);
                }
            }
        }
        return products;
    }

    private ArrayList<QualityCalculateRow> getProducts() {
        ArrayList<QualityCalculateRow> products = new ArrayList<>();
        for (AbstractRow model : this.rowsFromTable) {
            QualityRow quality = (QualityRow) model;
            int id;
            double currentPoint = quality.importance / 10. * (quality.point + quality.point_buyers);
            if((id = isHaveId(products, quality.product_id)) != -1) {
                products.get(id).point = (products.get(id).point + currentPoint)/2;
            } else {
                ProductRow productRow = getProduct(quality.product_id);
                products.add(new QualityCalculateRow(
                        quality.product_id,
                        productRow.name,
                        currentPoint,
                        productRow.price,
                        productRow.self_price
                ));
            }
        }
        return products;
    }

    private ProductRow getProduct(int product_id) {
        for (AbstractRow product :
                WindowCRUD.findMeMoreData(ProductRow.class)) {
            if(((ProductRow)product).id == product_id) {
                return (ProductRow)product;
            }
        }
        return new ProductRow(0, "", 0, 0, 0);
    }

    private int isHaveId(ArrayList<QualityCalculateRow> products, int product_id) {
        for (int i = 0; i < products.size(); i++) {
            if(products.get(i).id == product_id) {
                return i;
            }
        }
        return -1;
    }

    private void setEventScrin(int adminChecking){
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    //BufferedImage image =// new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
                    BufferedImage image = new BufferedImage(
                            currentTableDialog.getWidth(),
                            currentTableDialog.getHeight(),
                            BufferedImage.TYPE_INT_RGB
                    );
                    currentTableDialog.paint( image.getGraphics() );
                    ImageIO.write(image, "png", new File(thisClass.getSimpleName()+".png"));
                } catch (Exception exep){
                    JOptionPane.showMessageDialog(currentTableDialog, "Ошибка работы программы!\n скрининга!");
                }
            }

        };
        if(adminChecking == 0) currentTableDialog.ThisButtons.get(6).addActionListener(actionListener);
         else currentTableDialog.ThisButtons.get(3).addActionListener(actionListener);

    }

    public static ArrayList<AbstractRow> updateData(Class<? extends AbstractRow> thisClass, WindowCreator thisDialog){
        ArrayList<AbstractRow> table;
        if((table = WindowCRUD.findMeMoreData(thisClass)) == null) notError( thisDialog);

        thisDialog.ThisTable.get(0).setModel(getModel(table, thisClass));
        return table;
    }

    private static void notError( WindowCreator thisDialog){
        JOptionPane.showMessageDialog(thisDialog, "Ошибка работы программы!\n получения данных!");
        thisDialog.dispose();
    }


    public static String getCurrentTable(Class<? extends AbstractRow> thisClass){
        switch (thisClass.getName()) {
            default:
            case "entities.AccountRow":          return "accounts";
            case "entities.QualityRow":         return "qualitys";
            case "entities.ProductRow":     return "products";
            case "entities.StoreRow":     return "stores";
            case "entities.WorkerRow":         return "workers";
        }
    }


}
