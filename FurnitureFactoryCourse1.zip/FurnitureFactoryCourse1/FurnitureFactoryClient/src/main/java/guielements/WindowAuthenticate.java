package guielements;

import servertcp.Gsonizator;
import entities.AccountRow;


import javax.swing.*;
import java.awt.event.*;

public class WindowAuthenticate {
    private WindowCreator newDialogMain = null;

    public void goGet(){
        String answer = Gsonizator.goGetConnection();
        createOne();
        if(!answer.equals("")) {
            JOptionPane.showMessageDialog(newDialogMain, answer);
            newDialogMain.dispose();
        }
    }

    private void createOne(){
        newDialogMain = new WindowCreator("Аутентификация в систему!", 250, 270);
        creatCurrentDialog();
        newDialogMain.setVisible(true);
    }


    private void creatCurrentDialog(){
        prepareThisDialog();
        addActionListemer();
        addWindowListemer();
    }

    private void prepareThisDialog(){
            newDialogMain.addLabel(200, 40,20, 20, "Имя пользователя:");
        newDialogMain.addTextField(200, 40,20, 50, "");
            newDialogMain.addLabel(200, 40,20, 100, "Пароль:");
        newDialogMain.addTextField(200, 40,20, 130, "");
           newDialogMain.addButton(200, 40, 20, 180, "Вход");
    }

    public void addActionListemer() {
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(isGoodParams()) {
                    AccountRow this_account;
                    if((this_account = autorisationCheck(newDialogMain.ThisFields.get(0).getText().trim(),
                            newDialogMain.ThisFields.get(1).getText().trim())) != null){
                            addDefAutorJob(this_account);
                    } else {
                        JOptionPane.showMessageDialog(newDialogMain, "Плохая информация!");
                    }
                }
            }
            private void addDefAutorJob(AccountRow this_account){
                ClientRunner creator = new ClientRunner();
                creator.createDialog(newDialogMain, this_account.accountRole);
                creator.getcurrentDataTable();
                setText();
            }

            private void setText(){
                newDialogMain.ThisFields.get(0).setText("");
                newDialogMain.ThisFields.get(1).setText("");
                newDialogMain.dispose();
            }
        };
        newDialogMain.ThisButtons.get(0).addActionListener(actionListener);
    }

    public void addWindowListemer() {
        WindowListener windowListener = new WindowListener() {
            @Override
            public void windowClosing(WindowEvent event) {
                Gsonizator.exit();
            }
            public void windowActivated(WindowEvent event) {}
            public void windowClosed(WindowEvent event) {}
            public void windowDeactivated(WindowEvent event) {}
            public void windowDeiconified(WindowEvent event) {}
            public void windowIconified(WindowEvent event) {}
            public void windowOpened(WindowEvent event) {}
        };
        newDialogMain.addWindowListener(windowListener);
    }

    private boolean isGoodParams(){
        boolean isOk = true;
        String login, password, errors = "";
        login = newDialogMain.ThisFields.get(0).getText().trim();
        password = newDialogMain.ThisFields.get(1).getText().trim();
        if("".equals(login)){
            errors += "Логин пуст!";
            isOk = false;
        }
        if("".equals(password)){
            errors += "Пароль пуст!";
            isOk = false;
        }

        if (!isOk) JOptionPane.showMessageDialog(newDialogMain, errors);
        return isOk;
    }

    private AccountRow autorisationCheck(String login, String password){
        return Gsonizator.checkAuthorization(new AccountRow (0, login,password,2, 0));
    }

    public static boolean integerCheck(String string){
        try {
            return Integer.valueOf(string) >= 0;
        } catch (Exception e) {
            return false;
        }
    }

}
