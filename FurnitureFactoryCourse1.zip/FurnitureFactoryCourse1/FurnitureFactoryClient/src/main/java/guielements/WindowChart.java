package guielements;

import entities.QualityCalculateRow;
import entities.QualityRow;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.Dataset;
import org.jfree.ui.RectangleInsets;

import java.awt.*;
import java.util.ArrayList;

public class WindowChart {

    public WindowChart (ArrayList<QualityRow> rows){
//        CategoryDataset dataset = this.createDataset(rows);
//        createChart(dataset);

        JFreeChart chart = createChart(this.createDataset(rows));
        chart.setPadding(new RectangleInsets(4, 8, 2, 2));
        ChartPanel panel = new ChartPanel(chart);
        panel.setFillZoomRectangle(true);
        panel.setMouseWheelEnabled(true);
        panel.setPreferredSize(new Dimension(600, 300));
        WindowCreator dialog = new WindowCreator("График", 600, 600);
        dialog.setContentPane(panel);
        dialog.setVisible(true);
    }

    private JFreeChart createChart(CategoryDataset dataset)
    {
        JFreeChart chart = ChartFactory.createBarChart(
                "Оценки продукции компании",
                null,                   // x-axis label
                "Балл",                // y-axis label
                dataset);
        chart.setBackgroundPaint(Color.white);

        CategoryPlot plot = (CategoryPlot) chart.getPlot();

        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setDrawBarOutline(false);
        chart.getLegend().setFrame(BlockBorder.NONE);

        return chart;
    }

    private CategoryDataset createDataset(ArrayList<QualityRow> rows)
    {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (int i = 0; i < rows.size(); i++) {
            dataset.addValue(rows.get(i).point, "Общий балл", rows.get(i).name);
            dataset.addValue(rows.get(i).point_buyers, "Пользовательский балл", rows.get(i).name);
            dataset.addValue(rows.get(i).importance, "Важность", rows.get(i).name);
        }
        return dataset;
    }



}
