package guielements;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.util.ArrayList;

public class WindowCreator extends JFrame {
    private JPanel thisPanel;
    public ArrayList<JButton> ThisButtons = new ArrayList<>();
    public ArrayList<JTextField> ThisFields = new ArrayList<>();
    public ArrayList<JLabel> ThisLabels = new ArrayList<>();
    public ArrayList<JTextArea> ThisTextAreas = new ArrayList<>();
    public ArrayList<JTable> ThisTable = new ArrayList<>();
    public ArrayList<JComboBox> ThisLists = new ArrayList<>();

    public WindowCreator(String headerText, int width, int height){
        super(headerText);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(width, height);
        createOne();
    }

    private void createOne(){
        thisPanel = new JPanel();
        thisPanel.setBackground(Color.WHITE);
        thisPanel.setForeground(Color.BLACK);
        thisPanel.setLayout(null);
        setContentPane(thisPanel);
        setLocationRelativeTo(null);
    }


    public void addButton(int w, int h, int x, int y, String headerText){
        JButton myButton = new JButton(headerText);
        myButton.setSize(w, h);
        myButton.setLocation(x,y);
        myButton.setBackground(Color.WHITE);
        myButton.setForeground(Color.BLACK);

        thisPanel.add(myButton);

        ThisButtons.add(myButton);
    }


    public void addTextField(int w, int h, int x, int y, String string){
        JTextField myTextField = new JTextField(string);
        myTextField.setSize(w, h);
        myTextField.setLocation(x,y);
        myTextField.setForeground(Color.BLACK);

        thisPanel.add(myTextField);

        ThisFields.add(myTextField);
    }

    public void addLabel(int w, int h, int x, int y, String headerText){
        JLabel myLabel = new JLabel(headerText);
        myLabel.setSize(w, h);
        myLabel.setLocation(x,y);
        myLabel.setForeground(Color.BLACK);

        thisPanel.add(myLabel);

        ThisLabels.add(myLabel);
    }


    public void addComboBox(boolean isEditable, int w, int h, int x, int y){
        JComboBox myComboBox = new JComboBox();
        myComboBox.setEditable(isEditable);
        myComboBox.setSize(w, h);
        myComboBox.setLocation(x,y);
        myComboBox.setBackground(Color.WHITE);
        myComboBox.setForeground(Color.BLACK);
        thisPanel.add(myComboBox);

        ThisLists.add(myComboBox);
    }

    public void addTable(int w, int h, int x, int y, AbstractTableModel model){

        JTable myTable = new JTable(model);
        myTable.setSize(w, h);
        myTable.setLocation(x,y);
        myTable.setBackground(Color.WHITE);
        myTable.setForeground(Color.BLACK);

        JScrollPane scrollPane = new JScrollPane(myTable);
        scrollPane.setBackground(Color.WHITE);
        scrollPane.setForeground(Color.BLACK);
        scrollPane.setSize(w, h);
        scrollPane.setLocation(x,y);

        thisPanel.add(scrollPane);
        ThisTable.add(myTable);
    }


}




