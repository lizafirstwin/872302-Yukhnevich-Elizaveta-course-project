package guielements;


import servertcp.Gsonizator;
import entities.*;

import javax.swing.*;
import java.awt.event.*;


public class ClientRunner {
    private WindowCreator currentDataTable;
    private WindowCreator newDialogMain;
    private int adminChecking;

    public WindowCreator getcurrentDataTable() {
        currentDataTable.setVisible(true);
        return currentDataTable;
    }

    public void createDialog(WindowCreator newDialogMain, int adminChecking){
        this.adminChecking = adminChecking;
        currentDataTable = new WindowCreator("Развитие Мебельной Фабрики", 650, 350);
        initDialog();
        this.newDialogMain = newDialogMain;
    }

    private void initDialog(){
        setEventsForCloseDialog();
        trainingcurrentDataTable();
        setEventAccountRow();
        setEventQualityRow();
        setEventProductRow();
        setEventStoreRow();
        setEventWorker();
        setEventExit();
    }

    public void setEventsForCloseDialog() {
        WindowListener windowListener = new WindowListener() {
            public void windowActivated(WindowEvent event) {}
            public void windowClosed(WindowEvent event) {}
            public void windowDeactivated(WindowEvent event) {}
            public void windowDeiconified(WindowEvent event) {}
            public void windowIconified(WindowEvent event) {}
            public void windowOpened(WindowEvent event) {}

            public void windowClosing(WindowEvent event) {
                String answer = Gsonizator.exit();
                if(!answer.equals("")) {
                    JOptionPane.showMessageDialog(currentDataTable, answer);
                }
            }
        };
        currentDataTable.addWindowListener(windowListener);
    }

    public void trainingcurrentDataTable(){
        currentDataTable.addButton(600, 40,20, 10, "\"Акаунты\"");
        currentDataTable.addButton(600, 40,20, 60, "\"Качество продукции\"");
        currentDataTable.addButton(600, 40,20, 110, "\"Продукты\"");
        currentDataTable.addButton(600, 40,20, 160, "\"Склады\"");
        currentDataTable.addButton(600, 40,20, 210, "\"Работники\"");
        currentDataTable.addButton(600, 40,20, 260, "УЙТИ");

    }


    protected void setEventAccountRow(){
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                WindowCRUD dialog = new WindowCRUD(AccountRow.class,currentDataTable, "\"Акаунты\"", adminChecking);
                dialog.create();
            }
        };
        currentDataTable.ThisButtons.get(0).addActionListener(actionListener);
    }

    protected void setEventQualityRow(){
        currentDataTable.ThisButtons.get(1).addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                WindowCRUD dialog = new WindowCRUD(QualityRow.class,currentDataTable,  "\"Качество продукции\"", adminChecking);
                dialog.create();
            }
        });
    }

    protected void setEventProductRow(){
        currentDataTable.ThisButtons.get(2).addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                WindowCRUD dialog = new WindowCRUD(ProductRow.class, currentDataTable, "\"Продукты\"", adminChecking);
                dialog.create();
            }
        });
    }

    protected void setEventStoreRow(){
        currentDataTable.ThisButtons.get(3).addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                WindowCRUD dialog = new WindowCRUD(StoreRow.class,currentDataTable, "\"Склады\"", adminChecking);
                dialog.create();
            }
        });
    }


    protected void setEventWorker(){
        currentDataTable.ThisButtons.get(4).addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                WindowCRUD dialog = new WindowCRUD(WorkerRow.class,currentDataTable, "\"Работники\"", adminChecking);
                dialog.create();
            }
        });
    }


    protected ActionListener setEventExit(){
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentDataTable.dispose();
                newDialogMain.setVisible(true);
            }
        };
        currentDataTable.ThisButtons.get(5).addActionListener(actionListener);
        return actionListener;
    }
}
