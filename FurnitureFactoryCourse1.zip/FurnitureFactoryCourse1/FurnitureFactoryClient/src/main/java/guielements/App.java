package guielements;

public class App {
    public static void main(String[] args) {
        WindowAuthenticate windowAuthenticate = new WindowAuthenticate();
        windowAuthenticate.goGet();
    }
}
